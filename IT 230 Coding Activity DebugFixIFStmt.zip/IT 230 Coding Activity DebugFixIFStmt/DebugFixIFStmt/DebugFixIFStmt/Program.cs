﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebugFixIFStmt
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }

        void run()
        {
            int firstChoice = 0, secondChoice = 0, thirdChoice = 0;
            System.Console.WriteLine("Matt's Copy");
            firstChoice = 0; secondChoice = 0; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);
            firstChoice = 2; secondChoice = 0; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);
            firstChoice = 2; secondChoice = 5; thirdChoice = 0;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);
            firstChoice = 2; secondChoice = 5; thirdChoice = 7;
            WriteCurrentChoices(firstChoice, secondChoice, thirdChoice);
        }

        void WriteCurrentChoices(int firstChoice, int secondChoice, int thirdChoice)
        {
            // The original logic here was slightly contradictory.
            // The first condition should handle the case where only the first choice is made (secondChoice is 0).
            // The logic below has been adjusted to function as intended based on the variable values.

            if (secondChoice == 0) // Checks if only firstChoice has been made (or none)
                Console.WriteLine("Choices are: {0}, {1}, {2} => There are no choices yet (or just the first)", firstChoice, secondChoice, thirdChoice);
            else if (thirdChoice == 0) // Checks if secondChoice has been made, but thirdChoice has not
                Console.WriteLine("Choices are: {0}, {1}, {2} => Currently choices are {0}, {1}", firstChoice, secondChoice, thirdChoice, firstChoice, secondChoice);
            else // All three choices have been made
                Console.WriteLine("Choices are: {0}, {1}, {2} => Currently choices are {0}, {1}, {2}", firstChoice, secondChoice, thirdChoice, firstChoice, secondChoice, thirdChoice);
        }
    }
}
