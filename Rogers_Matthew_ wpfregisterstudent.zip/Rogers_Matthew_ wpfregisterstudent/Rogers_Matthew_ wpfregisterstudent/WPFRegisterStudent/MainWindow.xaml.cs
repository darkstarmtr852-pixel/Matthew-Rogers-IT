﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Fix 1: Declare creditHours as a class-level field to track total credits
        private int creditHours = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Populate ComboBox
            this.comboBox.Items.Add(new Course("IT 145"));
            this.comboBox.Items.Add(new Course("IT 200"));
            this.comboBox.Items.Add(new Course("IT 201"));
            this.comboBox.Items.Add(new Course("IT 270"));
            this.comboBox.Items.Add(new Course("IT 315"));
            this.comboBox.Items.Add(new Course("IT 328"));
            this.comboBox.Items.Add(new Course("IT 330"));

            this.textBox.Text = "0";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Fix 2: Check if an item is selected before casting
            if (this.comboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a course first.");
                return;
            }

            Course choice = (Course)this.comboBox.SelectedItem;

            // Business Rule: No duplicate registration
            if (this.listBox.Items.Contains(choice))
            {
                this.label3.Content = "Error: You have already registered for " + choice.ToString();
                MessageBox.Show("You cannot register for the same course twice.");
            }
            // Business Rule: Max 9 credit hours (max 3 courses)
            else if (creditHours >= 9)
            {
                this.label3.Content = "Error: Maximum 9 credit hours reached.";
                MessageBox.Show("You cannot register for more than 9 credit hours.");
            }
            else
            {
                // Successful Registration
                this.listBox.Items.Add(choice);
                creditHours += 3;
                this.textBox.Text = creditHours.ToString();
                this.label3.Content = "Registration confirmed for: " + choice.ToString();
                MessageBox.Show("Registration successful!");
            }
        }
    }
}