﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebugFixMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }

        void run()
        {
            int choice = 0;
            WritePrompt();
            choice = ReadChoice();
            WriteChoice(choice);
        }

        // Corrected method name to match call in run()
        void WritePrompt()
        {
            Console.WriteLine("Please select a course for which you want to register by typing the number inside []");
            Console.WriteLine("[1]IT 145\n[2]IT 200\n[3]IT 201\n[4]IT 270\n[5]IT 315\n[6]IT 328\n[7]IT 330");
            Console.Write("Enter your choice : ");
        }

        int ReadChoice()
        {
            string s = "";
            s = Console.ReadLine();
            // Explicitly convert the string input to an integer
            return int.Parse(s);
        }

        // Added 'int' data type for the parameter
        void WriteChoice(int choice)
        {
            // Corrected variable name to match the parameter name (case-sensitive)
            Console.WriteLine("Your choice is {0}", choice);
        }
    }
}
