﻿using System;

namespace CreateClassesObjs
{
    public class Course
    {
        // Field to store the course name
        private string name;

        // Setter method used in your MainWindow code
        public void setName(string courseName)
        {
            this.name = courseName;
        }

        // Getter method (optional, but good practice)
        public string getName()
        {
            return this.name;
        }

        // Overriding ToString tells the ComboBox/ListBox what text to display
        public override string ToString()
        {
            return this.name;
        }
    }
}